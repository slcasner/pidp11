Freshly installed unix v7,

as per http://a.papnet.eu/UNIX/v7/Installation

See the site for full manual set and overview
 